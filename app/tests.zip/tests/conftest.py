# tests/conftest.py
import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from app.api import api
from app.backend.controllers.base_controller import engine
from dotenv import load_dotenv


@pytest.fixture(autouse=True)
def load_env():
    load_dotenv(".env.test")


@pytest.fixture
def client(mocker):
    test_engine = create_engine(os.environ['DATABASE_URL'])
    mocker.patch("app.backend.controllers.base_controller.engine", test_engine)
    return TestClient(api)
