# tests/test_utils.py
import pytest
from app.utils import (
    construct_collection_name,
    protect_chat,
    extend_context,
    get_pdf_path,
    initialize_rag,
    save_documents,
    DocHandler,
    PDFHandler,
    TextHandler
)
from app.backend.models.users import User
from app.rag_generator import RagSystem
from fastapi import UploadFile, Request
import os
import uuid
from unittest.mock import AsyncMock

# Test construct_collection_name
@pytest.mark.asyncio
async def test_construct_collection_name_valid():
    """Test constructing collection name with valid user and chat_id."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    result = construct_collection_name(user, chat_id)
    assert result == "user_id_1_chat_id_123", "Should return correct collection name"

@pytest.mark.asyncio
async def test_construct_collection_name_zero_chat_id():
    """Test constructing collection name with chat_id = 0."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 0
    result = construct_collection_name(user, chat_id)
    assert result == "user_id_1_chat_id_0", "Should handle zero chat_id correctly"

@pytest.mark.asyncio
async def test_construct_collection_name_none_user():
    """Test constructing collection name with None user, expecting AttributeError."""
    user = None
    chat_id = 123
    with pytest.raises(AttributeError):
        construct_collection_name(user, chat_id)

# Test protect_chat
@pytest.mark.asyncio
async def test_protect_chat_valid(mocker):
    """Test protect_chat with valid user and chat_id where user has ownership."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    mocker.patch("app.utils.verify_ownership_rights", return_value=True)
    result = protect_chat(user, chat_id)
    assert result is True, "Should return True when user has ownership"

@pytest.mark.asyncio
async def test_protect_chat_no_ownership(mocker):
    """Test protect_chat when user does not have ownership."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    mocker.patch("app.utils.verify_ownership_rights", return_value=False)
    result = protect_chat(user, chat_id)
    assert result is False, "Should return False when user lacks ownership"

@pytest.mark.asyncio
async def test_protect_chat_none_user():
    """Test protect_chat with None user, expecting AttributeError."""
    chat_id = 123
    with pytest.raises(AttributeError):
        protect_chat(None, chat_id)

@pytest.mark.asyncio
async def test_protect_chat_negative_chat_id(mocker):
    """Test protect_chat with negative chat_id, expecting False."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = -1
    mocker.patch("app.utils.verify_ownership_rights", return_value=False)
    result = protect_chat(user, chat_id)
    assert result is False, "Should return False for negative chat_id"

# Test extend_context
@pytest.mark.asyncio
async def test_extend_context_valid_user(mocker):
    """Test extend_context with valid user and request."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    mocker.patch("app.utils.get_current_user", return_value=user)
    mocker.patch("app.utils.list_user_chats", return_value=[{"id": 1}, {"id": 2}])
    context = {"request": mocker.Mock(spec=Request)}
    result = extend_context(context, selected=1)
    assert result["navbar_context"]["user"]["role"] == "user", "Should set role to user"
    assert result["sidebar_context"]["chat_groups"] == [{"id": 1}, {"id": 2}], "Should include user chats"
    assert result["sidebar_context"]["selected"] == 1, "Should set selected chat"
    assert result["footer"] is False, "Footer should be False"

@pytest.mark.asyncio
async def test_extend_context_guest_user(mocker):
    """Test extend_context with no authenticated user (guest)."""
    mocker.patch("app.utils.get_current_user", return_value=None)
    mocker.patch("app.utils.list_user_chats", return_value=[])
    context = {"request": mocker.Mock(spec=Request)}
    result = extend_context(context, selected=None)
    assert result["navbar_context"]["user"]["role"] == "guest", "Should set role to guest"
    assert result["sidebar_context"]["chat_groups"] == [], "Should have empty chat list for guest"
    assert result["sidebar_context"]["selected"] is None, "Selected should be None"

@pytest.mark.asyncio
async def test_extend_context_none_request():
    """Test extend_context with None request, expecting KeyError."""
    context = {"request": None}
    with pytest.raises(KeyError):
        extend_context(context)

# Test get_pdf_path
@pytest.mark.asyncio
async def test_get_pdf_path_valid():
    """Test get_pdf_path with valid PDF path."""
    path = "/app/chats_storage/user_id=1/chat_id=123/documents/pdfs/test.pdf"
    result = get_pdf_path(path)
    assert result == "chats_storage/user_id=1/chat_id=123/documents/pdfs/test.pdf", "Should return correct PDF path"

@pytest.mark.asyncio
async def test_get_pdf_path_non_pdf():
    """Test get_pdf_path with non-PDF file, expecting RuntimeError."""
    path = "/app/chats_storage/user_id=1/chat_id=123/documents/test.txt"
    with pytest.raises(RuntimeError):
        get_pdf_path(path)

@pytest.mark.asyncio
async def test_get_pdf_path_invalid_path():
    """Test get_pdf_path with path missing chats_storage, expecting empty string."""
    path = "/invalid/path/test.pdf"
    result = get_pdf_path(path)
    assert result == "", "Should return empty string for invalid path"

# Test initialize_rag
@pytest.mark.asyncio
async def test_initialize_rag_none(mocker):
    """Test initialize_rag when rag is None, expecting new instance."""
    mocker.patch("app.utils.rag", None)
    mock_rag = mocker.Mock(spec=RagSystem)
    mocker.patch("app.utils.RagSystem", return_value=mock_rag)
    result = initialize_rag()
    assert result == mock_rag, "Should return new RagSystem instance"

@pytest.mark.asyncio
async def test_initialize_rag_existing(mocker):
    """Test initialize_rag when rag already exists, expecting same instance."""
    mock_rag = mocker.Mock(spec=RagSystem)
    mocker.patch("app.utils.rag", mock_rag)
    result = initialize_rag()
    assert result == mock_rag, "Should return existing rag instance"

# Test save_documents
@pytest.mark.asyncio
async def test_save_documents_valid_pdf(mocker, tmp_path):
    """Test save_documents with valid PDF file."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    mock_rag = mocker.Mock(spec=RagSystem)
    file = mocker.Mock(spec=UploadFile, filename="test.pdf", read=AsyncMock(return_value=b"content"))
    mocker.patch("app.utils.base_path", str(tmp_path))
    mocker.patch("os.makedirs")
    mocker.patch("builtins.open", mocker.mock_open())
    await save_documents("collection_name", [file], mock_rag, user, chat_id)
    mock_rag.upload_documents.assert_called_once()
    assert mock_rag.upload_documents.call_args[0][0] == "collection_name", "Should call upload_documents with correct collection"
    assert mock_rag.upload_documents.call_args[0][1][0].endswith(".pdf"), "Should save file with .pdf extension"

@pytest.mark.asyncio
async def test_save_documents_none_files(mocker):
    """Test save_documents with None files, expecting no action."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    mock_rag = mocker.Mock(spec=RagSystem)
    await save_documents("collection_name", None, mock_rag, user, chat_id)
    mock_rag.upload_documents.assert_not_called(), "Should not call upload_documents with None files"

@pytest.mark.asyncio
async def test_save_documents_empty_files(mocker):
    """Test save_documents with empty files list, expecting no action."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    mock_rag = mocker.Mock(spec=RagSystem)
    await save_documents("collection_name", [], mock_rag, user, chat_id)
    mock_rag.upload_documents.assert_not_called(), "Should not call upload_documents with empty files list"

@pytest.mark.asyncio
async def test_save_documents_non_pdf(mocker, tmp_path):
    """Test save_documents with non-PDF file."""
    user = User(id=1, email="test@example.com", password_hash="hashed")
    chat_id = 123
    mock_rag = mocker.Mock(spec=RagSystem)
    file = mocker.Mock(spec=UploadFile, filename="test.txt", read=AsyncMock(return_value=b"content"))
    mocker.patch("app.utils.base_path", str(tmp_path))
    mocker.patch("os.makedirs")
    mocker.patch("builtins.open", mocker.mock_open())
    await save_documents("collection_name", [file], mock_rag, user, chat_id)
    mock_rag.upload_documents.assert_called_once()
    assert mock_rag.upload_documents.call_args[0][1][0].endswith(".txt"), "Should save file with correct extension"

# Test DocHandler
@pytest.mark.asyncio
async def test_doc_handler():
    """Test DocHandler, expecting None as it is a placeholder."""
    result = DocHandler()
    assert result is None, "DocHandler should return None as it is not implemented"

# Test PDFHandler
@pytest.mark.asyncio
async def test_pdf_handler_valid(mocker):
    """Test PDFHandler with valid path and user."""
    request = mocker.Mock(spec=Request)
    user = User(id=1, email="test@example.com", password_hash="hashed")
    mocker.patch("app.utils.get_pdf_path", return_value="chats_storage/user_id=1/chat_id=123/test.pdf")
    mocker.patch("app.utils.get_current_user", return_value=user)
    templates = mocker.Mock()
    result = PDFHandler(request, path="/app/chats_storage/user_id=1/chat_id=123/test.pdf", page=1, templates=templates)
    assert result.template == "pages/show_pdf.html", "Should use correct template"
    assert result.context["url_path"] == "chats_storage/user_id=1/chat_id=123/test.pdf", "Should pass correct URL path"
    assert result.context["user"] == user, "Should include correct user"

@pytest.mark.asyncio
async def test_pdf_handler_invalid_path(mocker):
    """Test PDFHandler with invalid path, expecting RuntimeError from get_pdf_path."""
    request = mocker.Mock(spec=Request)
    mocker.patch("app.utils.get_pdf_path", side_effect=RuntimeError("Not a pdf file"))
    mocker.patch("app.utils.get_current_user", return_value=User(id=1, email="test@example.com", password_hash="hashed"))
    templates = mocker.Mock()
    with pytest.raises(RuntimeError):
        PDFHandler(request, path="invalid.txt", page=1, templates=templates)

# Test TextHandler
@pytest.mark.asyncio
async def test_text_handler_valid(mocker):
    """Test TextHandler with valid file and lines range."""
    request = mocker.Mock(spec=Request)
    user = User(id=1, email="test@example.com", password_hash="hashed")
    mocker.patch("app.utils.get_current_user", return_value=user)
    mocker.patch("builtins.open", mocker.mock_open(read_data="line1\nline2\nline3\nline4"))
    templates = mocker.Mock()
    result = TextHandler(request, path="test.txt", lines="2-3", templates=templates)
    assert result.template == "pages/show_text.html", "Should use correct template"
    assert result.context["text_before_citation"] == ["line1"], "Should include correct lines before citation"
    assert result.context["citation"] == ["line2", "line3"], "Should include correct citation lines"
    assert result.context["text_after_citation"] == ["line4"], "Should include correct lines after citation"
    assert result.context["anchor_added"] is True, "Should set anchor_added to True"

@pytest.mark.asyncio
async def test_text_handler_invalid_lines_format(mocker):
    """Test TextHandler with invalid lines format, expecting ValueError."""
    request = mocker.Mock(spec=Request)
    mocker.patch("app.utils.get_current_user", return_value=User(id=1, email="test@example.com", password_hash="hashed"))
    mocker.patch("builtins.open", mocker.mock_open(read_data="line1\nline2\nline3"))
    templates = mocker.Mock()
    with pytest.raises(ValueError):
        TextHandler(request, path="test.txt", lines="invalid", templates=templates)

@pytest.mark.asyncio
async def test_text_handler_empty_file(mocker):
    """Test TextHandler with empty file."""
    request = mocker.Mock(spec=Request)
    user = User(id=1, email="test@example.com", password_hash="hashed")
    mocker.patch("app.utils.get_current_user", return_value=user)
    mocker.patch("builtins.open", mocker.mock_open(read_data=""))
    templates = mocker.Mock()
    result = TextHandler(request, path="test.txt", lines="1-1", templates=templates)
    assert result.context["citation"] == [], "Should handle empty file with empty citation"
    assert result.context["anchor_added"] is False, "Should set anchor_added to False for empty file"

@pytest.mark.asyncio
async def test_text_handler_out_of_range_lines(mocker):
    """Test TextHandler with lines range beyond file content."""
    request = mocker.Mock(spec=Request)
    user = User(id=1, email="test@example.com", password_hash="hashed")
    mocker.patch("app.utils.get_current_user", return_value=user)
    mocker.patch("builtins.open", mocker.mock_open(read_data="line1\nline2"))
    templates = mocker.Mock()
    result = TextHandler(request, path="test.txt", lines="3-4", templates=templates)
    assert result.context["citation"] == [], "Should return empty citation for out-of-range lines"
    assert result.context["anchor_added"] is False, "Should set anchor_added to False for out-of-range lines"